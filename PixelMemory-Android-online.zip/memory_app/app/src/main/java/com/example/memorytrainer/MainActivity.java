package com.example.memorytrainer;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.speech.tts.TextToSpeech;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content; SharedPreferences prefs; Random rnd=new Random(); Handler handler=new Handler(Looper.getMainLooper());
    TextToSpeech tts; Runnable timerRun; int remaining; ArrayList<String> currentItems=new ArrayList<>(); String mode="";
    int ink=Color.rgb(22,36,58), panel=Color.rgb(243,240,223), accent=Color.rgb(216,107,156), blue=Color.rgb(90,143,174), gold=Color.rgb(242,200,91);
    int[] spriteIds={R.drawable.girl_park_happy,R.drawable.girl_bench_proud,R.drawable.girl_mall_happy,R.drawable.girl_park_sad,R.drawable.girl_bench_sad,R.drawable.girl_mall_angry};
    String[] easy={"яблоко","дом","река","стол","книга","солнце","лес","море","окно","мост","снег","чай","кошка","камень","сад","дорога","звезда","луна","письмо","фонарь","парк","цветок","музыка","дождь","гора","корабль","ручка","свеча","зеркало","ключ"};
    String[] medium={"яблоко","дом","быстрый","зелёный","река","смеяться","книга","тёплый","искать","дорога","письмо","тихий","прыгать","море","старый","звонить","звезда","сильный","рисовать","окно","лететь","голос","яркий","думать"};
    String[] hard={"любовь","чувства","только","но","однако","помнить","забывать","сомневаться","казаться","решать","верить","знать","держать","отпускать","встречать","пропускать","пытаться","слышать","взгляд","смысл","правда","время","вдруг","почти","никогда","потом"};

    @Override public void onCreate(Bundle b){super.onCreate(b); prefs=getSharedPreferences("p",0); setupTheme(); tts=new TextToSpeech(this,s->{ if(s==TextToSpeech.SUCCESS){tts.setLanguage(new Locale("ru","RU"));tts.setPitch(.72f);tts.setSpeechRate(.82f);} }); markVisit(); scheduleReminders(); if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},44); showHome();}
    @Override protected void onDestroy(){ if(tts!=null)tts.shutdown(); super.onDestroy(); }

    void setupTheme(){ getWindow().setStatusBarColor(blue); getWindow().setNavigationBarColor(ink); }
    GradientDrawable bg(int color,int radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(radius);g.setStroke(dp(2),ink);return g;}
    int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    TextView tv(String s,int size){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(ink);v.setTypeface(android.graphics.Typeface.MONOSPACE,android.graphics.Typeface.BOLD);v.setPadding(dp(12),dp(8),dp(12),dp(8));return v;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextSize(15);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setTypeface(android.graphics.Typeface.MONOSPACE,1);b.setPadding(dp(8),dp(6),dp(8),dp(6));b.setBackground(bg(blue,dp(12)));return b;}
    EditText edit(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextSize(17);e.setTextColor(ink);e.setHintTextColor(Color.DKGRAY);e.setSingleLine(false);e.setPadding(dp(12),dp(10),dp(12),dp(10));e.setBackground(bg(Color.WHITE,dp(10)));return e;}

    void base(String title){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(229,238,236));
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(14),dp(10),dp(14),dp(20));
        ScrollView sv=new ScrollView(this);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
        TextView head=tv("◈  "+title,20); head.setTextColor(Color.WHITE);head.setGravity(Gravity.CENTER_VERTICAL);head.setBackgroundColor(ink);root.addView(head,0,new LinearLayout.LayoutParams(-1,dp(58)));
    }
    void add(View v){content.addView(v,new LinearLayout.LayoutParams(-1,-2));}
    void gap(int h){Space s=new Space(this);add(s);s.getLayoutParams().height=dp(h);}
    void title(String s){TextView v=tv(s,18);v.setTextColor(ink);v.setGravity(Gravity.CENTER);add(v);}

    void showHome(){
        base("PIXEL MEMORY");
        FrameLayout hero=new FrameLayout(this); hero.setBackgroundResource(R.drawable.sky_pixel); hero.setMinimumHeight(dp(420));
        ImageView girl=new ImageView(this); int sid=spriteIds[rnd.nextInt(spriteIds.length)]; girl.setImageResource(sid);girl.setScaleType(ImageView.ScaleType.CENTER_INSIDE);hero.addView(girl,new FrameLayout.LayoutParams(-1,dp(330),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL));
        LinearLayout bubble=new LinearLayout(this);bubble.setOrientation(LinearLayout.VERTICAL);bubble.setPadding(dp(12),dp(7),dp(12),dp(7));bubble.setBackground(bg(panel,dp(10)));
        TextView speech=tv(getGreeting(),14);speech.setTextColor(ink);bubble.addView(speech);FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.CENTER_HORIZONTAL);bp.setMargins(dp(20),dp(18),dp(20),0);hero.addView(bubble,bp);add(hero);
        gap(10); add(btnRow("ЧИСЛА НА СКОРОСТЬ: ЭКРАН",v->showNumberSetup(false))); add(btnRow("ЧИСЛА НА СКОРОСТЬ: СЛУХ",v->showNumberSetup(true))); add(btnRow("СЛУЧАЙНЫЕ РУССКИЕ СЛОВА",v->showWordsSetup())); add(btnRow("ЗАМЕТКИ",v->showNotes())); add(btnRow("ПРОГРЕСС",v->showProgress()));
        TextView small=tv("Сегодня: "+new SimpleDateFormat("d MMMM",new Locale("ru","RU")).format(new Date())+"  •  серия: "+prefs.getInt("streak",1)+" дн.",13);small.setGravity(Gravity.CENTER);add(small);
    }
    Button btnRow(String s,View.OnClickListener l){Button b=btn(s);b.setOnClickListener(l);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(54));p.setMargins(0,dp(5),0,dp(5));b.setLayoutParams(p);return b;}
    String getGreeting(){int streak=prefs.getInt("streak",1); if(prefs.getBoolean("missed",false)) return "Я тебя ждала. Не пропадай надолго! Сегодня можно начать с 5 минут.\n— серия сбилась, но это не повод бросать."; String[] a={"Ты пришёл! Отлично. Давай сегодня ещё один маленький шаг.","Снова здесь — умница. Память любит регулярность.","Я вижу твой прогресс. Поехали ещё один раунд!","Сегодня тоже потренируем мозг? Я рядом.","Серия "+streak+" — не останавливайся!"};return a[rnd.nextInt(a.length)];}

    void showNumberSetup(boolean audio){base(audio?"ЧИСЛА • СЛУХ":"ЧИСЛА • ЭКРАН"); title(audio?"Робот произнесёт числа по очереди":"Запомни последовательность и введи её после таймера");
        add(tv("Количество чисел",15)); SeekBar count=new SeekBar(this);count.setMax(25);count.setProgress(7);add(count); TextView cval=tv("7",18);cval.setGravity(Gravity.CENTER);add(cval);count.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){cval.setText(String.valueOf(Math.max(1,p)));}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});
        add(tv("Время запоминания (сек.)",15));SeekBar time=new SeekBar(this);time.setMax(175);time.setProgress(25);add(time);TextView tval=tv("30",18);tval.setGravity(Gravity.CENTER);add(tval);time.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){tval.setText(String.valueOf(Math.max(5,p+5)));}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});
        gap(12);Button start=btn("НАЧАТЬ");add(start);start.setOnClickListener(v->{int n=Math.max(1,count.getProgress()),sec=Math.max(5,time.getProgress()+5);startNumbers(audio,n,sec);});
    }

    void startNumbers(boolean audio,int n,int sec){ mode=audio?"audio":"screen"; currentItems.clear();for(int i=0;i<n;i++)currentItems.add(String.format(Locale.US,"%04d",rnd.nextInt(10000)));base(audio?"СЛУХ • ЗАПОМИНАНИЕ":"ЭКРАН • ЗАПОМИНАНИЕ");
        TextView timer=tv(String.valueOf(sec),28);timer.setGravity(Gravity.CENTER);add(timer);TextView seq=tv(String.join("   ",currentItems),24);seq.setGravity(Gravity.CENTER);seq.setPadding(dp(6),dp(30),dp(6),dp(30));seq.setBackground(bg(panel,dp(12)));add(seq);TextView info=tv(audio?"Слушай. После таймера появится поле для ответа.":"Смотри внимательно. После таймера числа исчезнут.",13);info.setGravity(Gravity.CENTER);add(info);
        if(audio){seq.setText("🔊  слушай..."); int interval=Math.max(700,(sec*1000)/n); for(int i=0;i<n;i++){final int k=i;handler.postDelayed(()->{if(tts!=null)tts.speak(digitsForSpeech(currentItems.get(k)),TextToSpeech.QUEUE_ADD,null,"n"+k);},i*interval);} }
        remaining=sec;if(timerRun!=null)handler.removeCallbacks(timerRun);timerRun=new Runnable(){public void run(){timer.setText(String.valueOf(remaining));if(remaining<=0){if(tts!=null)tts.stop();showNumberInput();}else{remaining--;handler.postDelayed(this,1000);}}};handler.post(timerRun);
    }
    String digitsForSpeech(String s){StringBuilder b=new StringBuilder();for(char c:s.toCharArray())b.append(c).append(' ');return b.toString();}
    void showNumberInput(){base("ПРОВЕРКА");title("Введи числа в том же порядке");EditText ans=edit("Например: 0421 8190 5572");add(ans);gap(10);Button check=btn("ПРОВЕРИТЬ");add(check);check.setOnClickListener(v->{String typed=ans.getText().toString().replaceAll("[^0-9]"," ").trim().replaceAll("\\s+"," ");String expected=String.join(" ",currentItems);ArrayList<String> t=new ArrayList<>();if(!typed.isEmpty())t.addAll(Arrays.asList(typed.split(" ")));int good=0;for(int i=0;i<Math.min(t.size(),currentItems.size());i++)if(t.get(i).equals(currentItems.get(i)))good++;int pct=currentItems.size()==0?0:(int)(100.0*good/currentItems.size());recordSession(pct);base("РЕЗУЛЬТАТ");title(pct==100?"ИДЕАЛЬНО!":"Хорошая попытка!");TextView r=tv("Совпало: "+good+" из "+currentItems.size()+"\nТочность: "+pct+"%\n\nПравильный ответ:\n"+expected,18);r.setGravity(Gravity.CENTER);r.setBackground(bg(panel,dp(12)));add(r);gap(12);add(btnRow("НА ГЛАВНУЮ",x->showHome()));});}

    void showWordsSetup(){base("СЛОВА");title("Случайные русские слова");Spinner diff=new Spinner(this);String[] ds={"Лёгкий — существительные","Средний — разные части речи","Сложный — глаголы и неоднозначные слова"};ArrayAdapter<String> da=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,ds);diff.setAdapter(da);add(diff);
        add(tv("Количество слов",15));SeekBar count=new SeekBar(this);count.setMax(29);count.setProgress(9);add(count);TextView cv=tv("10",18);cv.setGravity(Gravity.CENTER);add(cv);count.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){cv.setText(String.valueOf(Math.max(1,p+1)));}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});
        add(tv("Время (сек.)",15));SeekBar time=new SeekBar(this);time.setMax(175);time.setProgress(25);add(time);TextView tv=tv("30",18);tv.setGravity(Gravity.CENTER);add(tv);time.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){tv.setText(String.valueOf(Math.max(5,p+5)));}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});
        Button b=btn("НАЧАТЬ");add(b);b.setOnClickListener(v->{int n=Math.max(1,count.getProgress()),sec=Math.max(5,time.getProgress()+5);startWords(diff.getSelectedItemPosition(),n,sec);});
    }
    void startWords(int level,int n,int sec){String[] src=level==0?easy:(level==1?medium:hard);currentItems.clear();for(int i=0;i<n;i++)currentItems.add(src[rnd.nextInt(src.length)]);base("СЛОВА • ЗАПОМИНАНИЕ");TextView timer=tv(String.valueOf(sec),28);timer.setGravity(Gravity.CENTER);add(timer);TextView list=tv(String.join("   •   ",currentItems),20);list.setGravity(Gravity.CENTER);list.setPadding(dp(8),dp(30),dp(8),dp(30));list.setBackground(bg(panel,dp(12)));add(list);TextView hint=tv("Запомни порядок.",14);hint.setGravity(Gravity.CENTER);add(hint);remaining=sec;if(timerRun!=null)handler.removeCallbacks(timerRun);timerRun=new Runnable(){public void run(){timer.setText(String.valueOf(remaining));if(remaining<=0)showWordInput();else{remaining--;handler.postDelayed(this,1000);}}};handler.post(timerRun);}
    void showWordInput(){base("СЛОВА • ПРОВЕРКА");title("Введи слова по порядку через пробел");EditText ans=edit("слово1 слово2 слово3...");add(ans);Button check=btn("ПРОВЕРИТЬ");add(check);check.setOnClickListener(v->{String typed=ans.getText().toString().toLowerCase(new Locale("ru")).trim().replaceAll("[.,;!?]"," ").replaceAll("\\s+"," ");String[] t=typed.isEmpty()?new String[0]:typed.split(" ");int good=0;for(int i=0;i<Math.min(t.length,currentItems.size());i++)if(t[i].equalsIgnoreCase(currentItems.get(i)))good++;int pct=(int)(100.0*good/currentItems.size());recordSession(pct);base("РЕЗУЛЬТАТ");TextView r=tv("Совпало: "+good+" из "+currentItems.size()+"\nТочность: "+pct+"%\n\nПравильная последовательность:\n"+String.join(" • ",currentItems),17);r.setGravity(Gravity.CENTER);r.setBackground(bg(panel,dp(12)));add(r);add(btnRow("НА ГЛАВНУЮ",x->showHome()));});}

    void showNotes(){base("ЗАМЕТКИ");title("Твои записи");EditText notes=edit("Пиши что угодно: мысли, планы, наблюдения...");notes.setMinHeight(dp(420));notes.setText(prefs.getString("notes",""));add(notes);Button save=btn("СОХРАНИТЬ");add(save);save.setOnClickListener(v->{prefs.edit().putString("notes",notes.getText().toString()).apply();Toast.makeText(this,"Сохранено",Toast.LENGTH_SHORT).show();});}
    void showProgress(){base("ПРОГРЕСС");int total=prefs.getInt("tests",0),best=prefs.getInt("best",0),last=prefs.getInt("last",0),streak=prefs.getInt("streak",1);title("Твоя статистика");TextView p=tv("🔥 Серия входов: "+streak+" дней\n\n🧠 Тренировок: "+total+"\n🏆 Лучшая точность: "+best+"%\n📈 Последняя точность: "+last+"%\n\nЦель на сегодня: хотя бы один короткий тест.",18);p.setBackground(bg(panel,dp(12)));add(p);gap(10);add(tv("Утреннее и вечернее напоминание включены. В настройках Android можно изменить разрешения уведомлений.",13));add(btnRow("НА ГЛАВНУЮ",v->showHome()));}

    void recordSession(int pct){prefs.edit().putInt("tests",prefs.getInt("tests",0)+1).putInt("last",pct).putInt("best",Math.max(prefs.getInt("best",0),pct)).apply();}
    void markVisit(){String today=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());String last=prefs.getString("lastDay","");if(today.equals(last))return;boolean missed=false;int streak=prefs.getInt("streak",0);try{if(!last.isEmpty()){Date a=new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(last);Date b=new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(today);long days=(b.getTime()-a.getTime())/86400000L;if(days==1)streak++;else if(days>1){streak=1;missed=true;}}else streak=1;}catch(Exception e){streak=1;}prefs.edit().putString("lastDay",today).putInt("streak",streak).putBoolean("missed",missed).apply();}
    void scheduleReminders(){AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);Calendar c=Calendar.getInstance();setAlarm(am,9,0,101);setAlarm(am,20,0,102);}
    void setAlarm(AlarmManager am,int hour,int minute,int id){Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,hour);c.set(Calendar.MINUTE,minute);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);if(c.getTimeInMillis()<System.currentTimeMillis())c.add(Calendar.DATE,1);PendingIntent pi=PendingIntent.getBroadcast(this,id,new Intent(this,ReminderReceiver.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);am.setInexactRepeating(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pi);}
}
