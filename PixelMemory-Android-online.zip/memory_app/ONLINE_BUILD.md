# Получение APK без Android Studio

1. Создай пустой репозиторий на GitHub.
2. Загрузи в него содержимое этой папки (файлы должны лежать в корне репозитория, а не внутри дополнительной папки memory_app).
3. Открой вкладку Actions.
4. Выбери workflow `Build APK`.
5. Нажми `Run workflow` (или просто сделай commit — workflow запускается и на push).
6. После успешной сборки открой запуск workflow и скачай artifact `PixelMemory-debug-apk`.
7. Внутри архива будет `app-debug.apk`. Передай APK на телефон и открой его для установки.

Workflow использует Java 17 и Gradle 8.10; Android Gradle Plugin проекта — 8.7.3.
